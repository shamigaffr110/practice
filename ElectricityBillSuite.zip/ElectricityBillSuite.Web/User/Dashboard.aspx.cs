using System;
public partial class User_Dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblName.Text = Session["UserName"]?.ToString() ?? "Guest";
    }
}
