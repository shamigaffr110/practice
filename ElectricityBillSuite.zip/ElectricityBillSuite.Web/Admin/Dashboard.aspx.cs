using System;
public partial class Admin_Dashboard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["IsAdmin"]==null) Response.Redirect("~/Account/AdminLogin.aspx");
    }
}
