using System;
using System.Data.SqlClient;
public partial class Account_AdminLogin : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string u = txtUser.Text.Trim(), p = txtPass.Text.Trim();
        var dt = DbHelper.GetDataTable("SELECT AdminID FROM Admins WHERE Username=@u AND Password=@p", new SqlParameter("@u", u), new SqlParameter("@p", p));
        if (dt.Rows.Count==1) { Session["IsAdmin"] = true; Response.Redirect("~/Admin/Dashboard.aspx"); }
        else lblMsg.Text = "Invalid";
    }
}
