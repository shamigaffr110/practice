using System;
using System.Data.SqlClient;
using System.Web.Security;
public partial class Account_Login : System.Web.UI.Page
{
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string email = txtEmail.Text.Trim();
        string pass = txtPass.Text.Trim();
        var dt = DbHelper.GetDataTable("SELECT UserID, FullName, PasswordHash FROM Users WHERE Email=@e", new SqlParameter("@e", email));
        if (dt.Rows.Count==1 && dt.Rows[0]["PasswordHash"].ToString()==pass)
        {
            FormsAuthentication.SetAuthCookie(email, false);
            Session["UserID"] = dt.Rows[0]["UserID"];
            Session["UserName"] = dt.Rows[0]["FullName"];
            Response.Redirect("~/User/Dashboard.aspx");
        }
        else lblMsg.Text = "Invalid credentials";
    }
}
