using System;
using System.Data.SqlClient;
public partial class Account_Register : System.Web.UI.Page
{
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        string name = txtName.Text.Trim();
        string email = txtEmail.Text.Trim();
        string pass = txtPass.Text.Trim();
        DbHelper.ExecuteNonQuery("INSERT INTO Users (FullName, Email, PasswordHash) VALUES (@n,@e,@p)", new SqlParameter("@n", name), new SqlParameter("@e", email), new SqlParameter("@p", pass));
        lblMsg.Text = "Registered. Please login.";
    }
}
