using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
public static class DbHelper
{
    private static string ConnString => ConfigurationManager.ConnectionStrings["DbConn"].ConnectionString;
    public static DataTable GetDataTable(string sql, params SqlParameter[] parameters)
    {
        using (var conn = new SqlConnection(ConnString))
        using (var cmd = new SqlCommand(sql, conn))
        {
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            using (var da = new SqlDataAdapter(cmd))
            {
                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
    }
    public static int ExecuteNonQuery(string sql, params SqlParameter[] parameters)
    {
        using (var conn = new SqlConnection(ConnString))
        using (var cmd = new SqlCommand(sql, conn))
        {
            if (parameters != null) cmd.Parameters.AddRange(parameters);
            conn.Open();
            return cmd.ExecuteNonQuery();
        }
    }
}
