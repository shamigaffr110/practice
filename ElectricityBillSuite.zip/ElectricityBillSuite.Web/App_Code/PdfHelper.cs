using System;
using System.IO;
public static class PdfHelper
{
    public static string CreateSimplePdf(string saveFolder, string fileName, string content)
    {
        Directory.CreateDirectory(saveFolder);
        string path = Path.Combine(saveFolder, fileName);
        File.WriteAllText(path, "PDF_PLACEHOLDER\n\n" + content);
        return path;
    }
}
