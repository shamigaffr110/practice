using System;
using System.Net;
using System.Net.Mail;
using System.Configuration;
public static class EmailService
{
    public static void Send(string toEmail, string subject, string body)
    {
        var smtpSection = ConfigurationManager.GetSection("system.net/mailSettings/smtp") as System.Net.Configuration.SmtpSection;
        string host = smtpSection.Network.Host;
        int port = smtpSection.Network.Port;
        bool enableSsl = smtpSection.Network.EnableSsl;
        string user = smtpSection.Network.UserName;
        string pass = smtpSection.Network.Password;
        var msg = new MailMessage();
        msg.From = new MailAddress(smtpSection.From ?? "no-reply@example.com");
        msg.To.Add(toEmail);
        msg.Subject = subject;
        msg.Body = body;
        msg.IsBodyHtml = true;
        using (var client = new SmtpClient(host, port))
        {
            client.EnableSsl = enableSsl;
            if (!string.IsNullOrEmpty(user)) client.Credentials = new NetworkCredential(user, pass);
            client.Send(msg);
        }
    }
}
