INSERT INTO Admins (Username, Password) VALUES ('admin','admin');
INSERT INTO Users (FullName, Email, PasswordHash, Phone) VALUES ('John Doe','john@example.com','pass123','9998887777');
